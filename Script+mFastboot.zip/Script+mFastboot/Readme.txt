aapt.exe         SHA1 e739c80424a973dded8ae7d58ae260c861ab0882
adb.exe          SHA1 6bd017aa930412878327f8ec5b4774f7e04fbb42
AdbWinApi.exe    SHA1 fde9c22a2cfcd5e566cec2e987d942b78a4eeae8
AdbWinUsbApi.exe SHA1 12e14244b1a5d04a261759547c3d930547f52fa3
linux-fastboot   SHA1 4ae92136d5d42bc1d5165b573c66acbc2f3ec145
mfastboot.exe    SHA1 702397514ce29b402b61c2e1c3160c47e4834544
osx-fastboot     SHA1 a011777b2f1d27222290d7b41dddd914b1139af8